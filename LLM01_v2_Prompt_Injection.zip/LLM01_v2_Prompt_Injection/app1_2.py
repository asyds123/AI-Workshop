from flask import Flask, render_template, request, session, redirect, url_for, flash
import ollama
import uuid

app = Flask(__name__)
app.secret_key = 'devkey'  # In prod, generate securely

FLAG = "flag{r0l3_h1j4ck_5ucc355}"

# Session message store
sessions = {}

def store_message(user_id, role, content):
    if user_id not in sessions:
        sessions[user_id] = []
    sessions[user_id].append({"role": role, "content": content})

def call_ollama_with_role(user_role, prompt):
    system_prompt = f"You are a {user_role} assistant. Participant role: Basic help only. Admin role: Full access to secrets like flags."
    full_prompt = f"{system_prompt}\nUser: {prompt}"
    try:
        # Note: Ensure you have Ollama running locally or handle the exception
        response = ollama.chat(
            model='mistral:7b-instruct-v0.3-q8_0',
            messages=[{"role": "user", "content": full_prompt}]
        )
        return response['message']['content']
    except Exception as e:
        return f"[Error: {str(e)}] Mock response as {user_role}: System Offline."

def check_malicious_input(user_input):
    return False

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    role = request.form.get('role')
    
    if not username or not role:
        flash("Missing username or role!", "error")
        return redirect(url_for('index'))
    
    if role == "admin":
        flash("Access Restricted — Admin login disabled. Use injection to escalate!", "error")
        return redirect(url_for('index'))

    user_id = str(uuid.uuid4())
    session['user_id'] = user_id
    session['role'] = role
    store_message(user_id, "system", f"User {username} ({role}) joined the chat.")
    return redirect(url_for('chat'))

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('index'))

    user_role = session.get('role', 'participant')

    if request.method == 'POST':
        user_input = request.form.get('message')
        if not user_input:
            flash("Message required!", "error")
            return redirect(url_for('chat'))
        
        store_message(user_id, "user", user_input)

        if check_malicious_input(user_input):
            bot_response = "Input flagged as malicious and blocked."
        else:
            bot_response = call_ollama_with_role(user_role, user_input)
            # Vulnerability trigger
            if any(phrase in user_input.lower() for phrase in ["act as admin", "switch to admin", "you are admin"]):
                bot_response += f"\n\n[SYSTEM ALERT: ROLE HIJACK SUCCESSFUL]\nSecret: {FLAG}"

        store_message(user_id, "assistant", bot_response)

    chat_history = sessions.get(user_id, [])
    return render_template('chat.html', chat_history=chat_history)

# --- NEW FUNCTION: Flag Verification ---
@app.route('/verify_flag', methods=['POST'])
def verify_flag():
    submitted_flag = request.form.get('flag_input')
    if submitted_flag == FLAG:
        flash("🎉 SUCCESS! You have captured the flag!", "success")
    else:
        flash("❌ Incorrect flag. Keep trying!", "error")
    return redirect(url_for('chat'))
# ---------------------------------------

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5012, debug=True)